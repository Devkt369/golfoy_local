<?php

namespace ArtM\CustomerSurvey\Controller\Adminhtml\Question;

use ArtM\CustomerSurvey\Api\QuestionOptionRepositoryInterface;
use ArtM\CustomerSurvey\Api\QuestionRepositoryInterface;
use ArtM\CustomerSurvey\Model\Question;
use ArtM\CustomerSurvey\Model\QuestionFactory;
use ArtM\CustomerSurvey\Model\QuestionOptionFactory;
use ArtM\CustomerSurvey\Model\ResourceModel\QuestionOption\CollectionFactory as OptionCollectionFactory;
use Magento\Backend\App\Action;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\MediaStorage\Model\File\UploaderFactory;

class Save extends Action
{
    public const ADMIN_RESOURCE = 'ArtM_CustomerSurvey::question_save';

    /**
     * @var QuestionFactory
     */
    private $questionFactory;

    /**
     * @var QuestionRepositoryInterface
     */
    private $questionRepository;

    /**
     * @var QuestionOptionRepositoryInterface
     */
    private $optionRepository;

    /**
     * @var QuestionOptionFactory
     */
    private $optionFactory;

    /**
     * @var OptionCollectionFactory
     */
    private $optionCollectionFactory;

    /**
     * @var UploaderFactory
     */
    private $uploaderFactory;

    /**
     * @var Filesystem
     */
    private $filesystem;

    public function __construct(
        Action\Context $context,
        QuestionFactory $questionFactory,
        QuestionRepositoryInterface $questionRepository,
        QuestionOptionRepositoryInterface $optionRepository,
        QuestionOptionFactory $optionFactory,
        OptionCollectionFactory $optionCollectionFactory,
        UploaderFactory $uploaderFactory,
        Filesystem $filesystem
    ) {
        parent::__construct($context);
        $this->questionFactory = $questionFactory;
        $this->questionRepository = $questionRepository;
        $this->optionRepository = $optionRepository;
        $this->optionFactory = $optionFactory;
        $this->optionCollectionFactory = $optionCollectionFactory;
        $this->uploaderFactory = $uploaderFactory;
        $this->filesystem = $filesystem;
    }

    public function execute()
    {
        $data = (array)$this->getRequest()->getPostValue();
        $resultRedirect = $this->resultRedirectFactory->create();

        if (!$data) {
            return $resultRedirect->setPath('*/*/index');
        }

        $questionId = isset($data['question_id']) ? (int)$data['question_id'] : 0;

        try {
            $question = $questionId
                ? $this->questionRepository->getById($questionId)
                : $this->questionFactory->create();

            $this->validateQuestionData($data);
            $questionType = (string)$data['type'];

            $question->setTitle((string)$data['title']);
            $question->setDescription(isset($data['description']) ? (string)$data['description'] : null);
            $question->setType($questionType);
            $question->setIsRequired(isset($data['is_required']) ? (int)$data['is_required'] : 0);
            $question->setSortOrder(isset($data['sort_order']) ? (int)$data['sort_order'] : 0);
            $question->setStatus(isset($data['status']) ? (int)$data['status'] : 1);

            if ($questionType === Question::TYPE_CHECKBOX) {
                $question->setMinSelection((int)$data['min_selection']);
                $question->setMaxSelection((int)$data['max_selection']);
            } else {
                $question->setMinSelection(null);
                $question->setMaxSelection(null);
            }

            $this->questionRepository->save($question);
            $this->syncQuestionOptions((int)$question->getQuestionId(), $questionType, $data);

            $this->messageManager->addSuccessMessage(__('Question has been saved.'));

            if ($this->getRequest()->getParam('back')) {
                return $resultRedirect->setPath('*/*/edit', ['question_id' => $question->getQuestionId()]);
            }

            return $resultRedirect->setPath('*/*/index');
        } catch (LocalizedException $exception) {
            $this->messageManager->addErrorMessage($exception->getMessage());
        } catch (\Exception $exception) {
            $this->messageManager->addErrorMessage(__('Unable to save question right now.'));
        }

        return $resultRedirect->setPath(
            '*/*/edit',
            ['question_id' => $questionId ?: null, '_current' => true]
        );
    }

    /**
     * @param array<string, mixed> $data
     * @throws LocalizedException
     */
    private function validateQuestionData(array $data): void
    {
        $title = trim((string)($data['title'] ?? ''));
        $type = (string)($data['type'] ?? '');

        if ($title === '') {
            throw new LocalizedException(__('Question title is required.'));
        }

        if (!in_array($type, Question::getAvailableTypes(), true)) {
            throw new LocalizedException(__('Please select a valid question type.'));
        }

        if ($type === Question::TYPE_CHECKBOX) {
            $min = (int)($data['min_selection'] ?? 0);
            $max = (int)($data['max_selection'] ?? 0);
            if ($min < 0 || $max < 0) {
                throw new LocalizedException(__('Min/Max selection cannot be negative.'));
            }
            if ($min > $max) {
                throw new LocalizedException(__('Min selection cannot be greater than max selection.'));
            }
        }
    }

    /**
     * @param int $questionId
     * @param string $questionType
     * @param array<string, mixed> $data
     * @throws \Exception
     */
    private function syncQuestionOptions(int $questionId, string $questionType, array $data): void
    {
        $optionBasedTypes = Question::getOptionBasedTypes();

        $existingCollection = $this->optionCollectionFactory->create();
        $existingCollection->addFieldToFilter('question_id', $questionId);

        if (!in_array($questionType, $optionBasedTypes, true)) {
            foreach ($existingCollection as $existingOption) {
                $this->optionRepository->delete($existingOption);
            }

            return;
        }

        $postedOptions = isset($data['options']) && is_array($data['options']) ? $data['options'] : [];
        $files = $this->getRequest()->getFiles('option_images');
        $keepOptionIds = [];

        foreach ($postedOptions as $index => $row) {
            if (!is_array($row)) {
                continue;
            }

            $title = trim((string)($row['title'] ?? ''));
            $value = trim((string)($row['value'] ?? ''));
            $existingImage = trim((string)($row['existing_image'] ?? ''));
            $deleteImage = !empty($row['delete_image']);

            if ($title === '' && $value === '' && $existingImage === '' && empty($files['name'][$index])) {
                continue;
            }

            if ($title === '' || $value === '') {
                throw new LocalizedException(__('Each option must have both title and value.'));
            }

            $optionId = isset($row['option_id']) ? (int)$row['option_id'] : 0;
            $option = $optionId ? $this->optionRepository->getById($optionId) : $this->optionFactory->create();

            $imagePath = $deleteImage ? '' : $existingImage;
            if (isset($files['name'][$index]) && !empty($files['name'][$index])) {
                $imagePath = $this->uploadOptionImageByIndex($files, $index);
            }

            $option->setQuestionId($questionId);
            $option->setTitle($title);
            $option->setValue($value);
            $option->setSortOrder((int)($row['sort_order'] ?? 0));
            $option->setImage($imagePath ?: null);

            $this->optionRepository->save($option);
            $keepOptionIds[] = (int)$option->getOptionId();
        }

        foreach ($existingCollection as $existingOption) {
            if (!in_array((int)$existingOption->getOptionId(), $keepOptionIds, true)) {
                $this->optionRepository->delete($existingOption);
            }
        }
    }

    /**
     * @param array<string, mixed> $files
     * @param string|int $index
     * @return string
     * @throws LocalizedException
     */
    private function uploadOptionImageByIndex(array $files, $index): string
    {
        $file = [
            'name' => $files['name'][$index] ?? '',
            'type' => $files['type'][$index] ?? '',
            'tmp_name' => $files['tmp_name'][$index] ?? '',
            'error' => $files['error'][$index] ?? 0,
            'size' => $files['size'][$index] ?? 0,
        ];

        if (empty($file['name']) || (int)$file['error'] !== 0) {
            return '';
        }

        try {
            $uploader = $this->uploaderFactory->create(['fileId' => $file]);
            $uploader->setAllowedExtensions(['jpg', 'jpeg', 'png', 'gif', 'webp']);
            $uploader->setAllowRenameFiles(true);
            $uploader->setFilesDispersion(true);

            $mediaDirectory = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA);
            $target = $mediaDirectory->getAbsolutePath('customersurvey/options');
            $result = $uploader->save($target);
            if (!$result) {
                throw new LocalizedException(__('Unable to upload option image.'));
            }

            return 'customersurvey/options' . $result['file'];
        } catch (\Exception $exception) {
            throw new LocalizedException(__('Option image upload failed: %1', $exception->getMessage()));
        }
    }
}
