<?php

declare(strict_types=1);

namespace ArtM\CustomerSurvey\Block\Frontend;

use Magento\Framework\View\Element\Template;
use Magento\Store\Model\StoreManagerInterface;

class Bootstrap extends Template
{
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    public function __construct(
        Template\Context $context,
        StoreManagerInterface $storeManager,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->storeManager = $storeManager;
    }

    /**
     * @return array<string, mixed>
     */
    public function getWidgetConfig(): array
    {
        $store = $this->storeManager->getStore();
        $baseUrl = rtrim($store->getBaseUrl(), '/');

        return [
            'storeId' => (int)$store->getId(),
            'api' => [
                'eligible' => $baseUrl . '/rest/V1/customersurvey/eligible',
                'impression' => $baseUrl . '/rest/V1/customersurvey/impression',
                'closed' => $baseUrl . '/rest/V1/customersurvey/closed',
                'popupOpen' => $baseUrl . '/rest/V1/customersurvey/popup-open',
                'submit' => $baseUrl . '/rest/V1/customersurvey/submit',
            ],
        ];
    }
}
