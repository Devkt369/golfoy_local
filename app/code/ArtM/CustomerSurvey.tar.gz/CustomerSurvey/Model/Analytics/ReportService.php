<?php

declare(strict_types=1);

namespace ArtM\CustomerSurvey\Model\Analytics;

use Magento\Framework\App\CacheInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\Serializer\Json;

class ReportService
{
    private const XML_PATH_CACHE_ENABLE = 'customersurvey/analytics/enable_cache';
    private const XML_PATH_CACHE_TTL = 'customersurvey/analytics/cache_ttl';

    /**
     * @var ResourceConnection
     */
    private $resource;

    /**
     * @var CacheInterface
     */
    private $cache;

    /**
     * @var Json
     */
    private $json;

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    public function __construct(
        ResourceConnection $resource,
        CacheInterface $cache,
        Json $json,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->resource = $resource;
        $this->cache = $cache;
        $this->json = $json;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @return array<string, mixed>
     */
    public function getSurveyListing(string $fromDate, string $toDate, int $page = 1, int $pageSize = 20): array
    {
        $page = max(1, $page);
        $pageSize = max(1, min(200, $pageSize));

        $cacheKey = $this->buildCacheKey('listing', [$fromDate, $toDate, $page, $pageSize]);
        $cached = $this->loadCache($cacheKey);
        if ($cached !== null) {
            return $cached;
        }

        $connection = $this->resource->getConnection();
        $surveyTable = $this->resource->getTableName('artm_customersurvey_survey');
        $statsTable = $this->resource->getTableName('artm_customersurvey_stats_daily');

        $statsSelect = $connection->select()
            ->from(
                ['sd' => $statsTable],
                [
                    'survey_id',
                    'impressions' => new \Zend_Db_Expr('SUM(sd.impressions)'),
                    'opens' => new \Zend_Db_Expr('SUM(sd.opens)'),
                    'responses' => new \Zend_Db_Expr('SUM(sd.responses)')
                ]
            )
            ->where('sd.stat_date >= ?', $fromDate)
            ->where('sd.stat_date <= ?', $toDate)
            ->where('sd.device = ?', 'all')
            ->where('sd.customer_type = ?', 'all')
            ->where('sd.location_id = ?', 0)
            ->group('sd.survey_id');

        $total = (int)$connection->fetchOne(
            $connection->select()->from($surveyTable, [new \Zend_Db_Expr('COUNT(*)')])
        );

        $rows = $connection->fetchAll(
            $connection->select()
                ->from(['s' => $surveyTable], ['survey_id', 'name', 'status'])
                ->joinLeft(['agg' => $statsSelect], 's.survey_id = agg.survey_id', [
                    'impressions' => new \Zend_Db_Expr('COALESCE(agg.impressions, 0)'),
                    'opens' => new \Zend_Db_Expr('COALESCE(agg.opens, 0)'),
                    'responses' => new \Zend_Db_Expr('COALESCE(agg.responses, 0)')
                ])
                ->order('s.priority DESC')
                ->order('s.sort_order ASC')
                ->limit($pageSize, ($page - 1) * $pageSize)
        );

        $items = [];
        foreach ($rows as $row) {
            $impressions = (int)$row['impressions'];
            $opens = (int)$row['opens'];
            $responses = (int)$row['responses'];
            $base = $opens > 0 ? $opens : $impressions;
            $completionRate = $base > 0 ? round(($responses / $base) * 100, 2) : 0.0;

            $items[] = [
                'survey_id' => (int)$row['survey_id'],
                'name' => (string)$row['name'],
                'status' => (string)$row['status'],
                'impressions' => $impressions,
                'opens' => $opens,
                'responses' => $responses,
                'completion_rate' => $completionRate,
            ];
        }

        $totals = $connection->fetchRow(
            $connection->select()
                ->from(['sd' => $statsTable], [
                    'impressions' => new \Zend_Db_Expr('COALESCE(SUM(sd.impressions), 0)'),
                    'opens' => new \Zend_Db_Expr('COALESCE(SUM(sd.opens), 0)'),
                    'responses' => new \Zend_Db_Expr('COALESCE(SUM(sd.responses), 0)')
                ])
                ->where('sd.stat_date >= ?', $fromDate)
                ->where('sd.stat_date <= ?', $toDate)
                ->where('sd.device = ?', 'all')
                ->where('sd.customer_type = ?', 'all')
                ->where('sd.location_id = ?', 0)
        ) ?: ['impressions' => 0, 'opens' => 0, 'responses' => 0];

        $trendRows = $connection->fetchAll(
            $connection->select()
                ->from(['sd' => $statsTable], [
                    'date' => 'sd.stat_date',
                    'impressions' => new \Zend_Db_Expr('COALESCE(SUM(sd.impressions), 0)'),
                    'opens' => new \Zend_Db_Expr('COALESCE(SUM(sd.opens), 0)'),
                    'responses' => new \Zend_Db_Expr('COALESCE(SUM(sd.responses), 0)')
                ])
                ->where('sd.stat_date >= ?', $fromDate)
                ->where('sd.stat_date <= ?', $toDate)
                ->where('sd.device = ?', 'all')
                ->where('sd.customer_type = ?', 'all')
                ->where('sd.location_id = ?', 0)
                ->group('sd.stat_date')
                ->order('sd.stat_date ASC')
        );

        $result = [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
            'totals' => [
                'impressions' => (int)$totals['impressions'],
                'opens' => (int)$totals['opens'],
                'responses' => (int)$totals['responses'],
            ],
            'trend' => $trendRows,
        ];

        $this->saveCache($cacheKey, $result);
        return $result;
    }

    /**
     * @return array<string, mixed>
     */
    public function getSurveyDetail(int $surveyId, string $fromDate, string $toDate): array
    {
        if ($surveyId <= 0) {
            throw new LocalizedException(__('Survey ID is required.'));
        }

        $cacheKey = $this->buildCacheKey('detail', [$surveyId, $fromDate, $toDate]);
        $cached = $this->loadCache($cacheKey);
        if ($cached !== null) {
            return $cached;
        }

        $connection = $this->resource->getConnection();
        $surveyTable = $this->resource->getTableName('artm_customersurvey_survey');
        $statsDailyTable = $this->resource->getTableName('artm_customersurvey_stats_daily');
        $statsAnswerTable = $this->resource->getTableName('artm_customersurvey_stats_answer_daily');
        $responseTable = $this->resource->getTableName('artm_customersurvey_response');
        $responseItemTable = $this->resource->getTableName('artm_customersurvey_response_item');
        $questionTable = $this->resource->getTableName('artm_customersurvey_question');
        $optionTable = $this->resource->getTableName('artm_customersurvey_question_option');
        $locationTable = $this->resource->getTableName('artm_customersurvey_location');

        $survey = $connection->fetchRow(
            $connection->select()
                ->from($surveyTable, ['survey_id', 'name', 'status'])
                ->where('survey_id = ?', $surveyId)
                ->limit(1)
        );
        if (!$survey) {
            throw new LocalizedException(__('Survey does not exist.'));
        }

        $totals = $connection->fetchRow(
            $connection->select()
                ->from(['sd' => $statsDailyTable], [
                    'impressions' => new \Zend_Db_Expr('COALESCE(SUM(sd.impressions), 0)'),
                    'opens' => new \Zend_Db_Expr('COALESCE(SUM(sd.opens), 0)'),
                    'responses' => new \Zend_Db_Expr('COALESCE(SUM(sd.responses), 0)'),
                ])
                ->where('sd.survey_id = ?', $surveyId)
                ->where('sd.stat_date >= ?', $fromDate)
                ->where('sd.stat_date <= ?', $toDate)
                ->where('sd.device = ?', 'all')
                ->where('sd.customer_type = ?', 'all')
                ->where('sd.location_id = ?', 0)
        ) ?: ['impressions' => 0, 'opens' => 0, 'responses' => 0];

        $answerDistribution = $connection->fetchAll(
            $connection->select()
                ->from(['sad' => $statsAnswerTable], [
                    'question_id',
                    'option_id',
                    'answer_type',
                    'answer_count' => new \Zend_Db_Expr('SUM(sad.answer_count)')
                ])
                ->join(['q' => $questionTable], 'q.question_id = sad.question_id', ['question_title' => 'q.title'])
                ->joinLeft(['qo' => $optionTable], 'qo.option_id = sad.option_id', ['option_title' => 'qo.title'])
                ->where('sad.survey_id = ?', $surveyId)
                ->where('sad.stat_date >= ?', $fromDate)
                ->where('sad.stat_date <= ?', $toDate)
                ->group(['sad.question_id', 'sad.option_id', 'sad.answer_type'])
                ->order('sad.question_id ASC')
                ->order('answer_count DESC')
        );

        $textResponses = $connection->fetchAll(
            $connection->select()
                ->from(['ri' => $responseItemTable], [
                    'question_id',
                    'answer_text',
                    'created_at' => 'r.created_at'
                ])
                ->join(['r' => $responseTable], 'r.response_id = ri.response_id', [])
                ->join(['q' => $questionTable], 'q.question_id = ri.question_id', ['question_title' => 'q.title'])
                ->where('r.survey_id = ?', $surveyId)
                ->where('r.created_at >= ?', $fromDate . ' 00:00:00')
                ->where('r.created_at <= ?', $toDate . ' 23:59:59')
                ->where('ri.answer_text IS NOT NULL')
                ->where('TRIM(ri.answer_text) <> ?', '')
                ->order('r.created_at DESC')
                ->limit(300)
        );

        $locationPerformance = $connection->fetchAll(
            $connection->select()
                ->from(['r' => $responseTable], [
                    'location_id' => new \Zend_Db_Expr('COALESCE(r.location_id, 0)'),
                    'responses' => new \Zend_Db_Expr('COUNT(*)')
                ])
                ->joinLeft(['l' => $locationTable], 'l.location_id = r.location_id', ['location_name' => 'l.name'])
                ->where('r.survey_id = ?', $surveyId)
                ->where('r.created_at >= ?', $fromDate . ' 00:00:00')
                ->where('r.created_at <= ?', $toDate . ' 23:59:59')
                ->group('location_id')
                ->order('responses DESC')
        );

        $deviceAnalytics = $connection->fetchAll(
            $connection->select()
                ->from(['sd' => $statsDailyTable], [
                    'device',
                    'impressions' => new \Zend_Db_Expr('SUM(sd.impressions)'),
                    'opens' => new \Zend_Db_Expr('SUM(sd.opens)'),
                    'responses' => new \Zend_Db_Expr('SUM(sd.responses)')
                ])
                ->where('sd.survey_id = ?', $surveyId)
                ->where('sd.stat_date >= ?', $fromDate)
                ->where('sd.stat_date <= ?', $toDate)
                ->where('sd.device <> ?', 'all')
                ->group('sd.device')
                ->order('responses DESC')
        );

        $customerTypeAnalytics = $connection->fetchAll(
            $connection->select()
                ->from(['sd' => $statsDailyTable], [
                    'customer_type',
                    'impressions' => new \Zend_Db_Expr('SUM(sd.impressions)'),
                    'opens' => new \Zend_Db_Expr('SUM(sd.opens)'),
                    'responses' => new \Zend_Db_Expr('SUM(sd.responses)')
                ])
                ->where('sd.survey_id = ?', $surveyId)
                ->where('sd.stat_date >= ?', $fromDate)
                ->where('sd.stat_date <= ?', $toDate)
                ->where('sd.customer_type <> ?', 'all')
                ->group('sd.customer_type')
                ->order('responses DESC')
        );

        $dateTrend = $connection->fetchAll(
            $connection->select()
                ->from(['sd' => $statsDailyTable], [
                    'date' => 'sd.stat_date',
                    'impressions' => new \Zend_Db_Expr('SUM(sd.impressions)'),
                    'opens' => new \Zend_Db_Expr('SUM(sd.opens)'),
                    'responses' => new \Zend_Db_Expr('SUM(sd.responses)')
                ])
                ->where('sd.survey_id = ?', $surveyId)
                ->where('sd.stat_date >= ?', $fromDate)
                ->where('sd.stat_date <= ?', $toDate)
                ->where('sd.device = ?', 'all')
                ->where('sd.customer_type = ?', 'all')
                ->where('sd.location_id = ?', 0)
                ->group('sd.stat_date')
                ->order('sd.stat_date ASC')
        );

        $result = [
            'survey' => [
                'survey_id' => (int)$survey['survey_id'],
                'name' => (string)$survey['name'],
                'status' => (string)$survey['status'],
            ],
            'totals' => [
                'impressions' => (int)$totals['impressions'],
                'opens' => (int)$totals['opens'],
                'responses' => (int)$totals['responses'],
            ],
            'answer_distribution' => $answerDistribution,
            'text_responses' => $textResponses,
            'location_performance' => $locationPerformance,
            'device_analytics' => $deviceAnalytics,
            'customer_type_analytics' => $customerTypeAnalytics,
            'date_trend' => $dateTrend,
        ];

        $this->saveCache($cacheKey, $result);
        return $result;
    }

    /**
     * @param array<int|string, mixed> $parts
     */
    private function buildCacheKey(string $prefix, array $parts): string
    {
        return 'artm_cs_report_' . $prefix . '_' . sha1($this->json->serialize($parts));
    }

    /**
     * @return array<string, mixed>|null
     */
    private function loadCache(string $cacheKey): ?array
    {
        if (!(bool)$this->scopeConfig->getValue(self::XML_PATH_CACHE_ENABLE)) {
            return null;
        }

        $cached = $this->cache->load($cacheKey);
        if (!$cached) {
            return null;
        }

        try {
            $decoded = $this->json->unserialize($cached);
            return is_array($decoded) ? $decoded : null;
        } catch (\InvalidArgumentException $e) {
            return null;
        }
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function saveCache(string $cacheKey, array $payload): void
    {
        if (!(bool)$this->scopeConfig->getValue(self::XML_PATH_CACHE_ENABLE)) {
            return;
        }

        $ttl = (int)$this->scopeConfig->getValue(self::XML_PATH_CACHE_TTL);
        if ($ttl <= 0) {
            $ttl = 900;
        }

        $this->cache->save($this->json->serialize($payload), $cacheKey, ['ARTM_CS_REPORT'], $ttl);
    }
}
