define([
    'jquery',
    'Magento_Customer/js/customer-data'
], function ($, customerData) {
    'use strict';

    var VISITOR_KEY = 'artm_cs_visitor_key';
    var PAGE_VIEWS_KEY = 'artm_cs_page_views';
    var LOGIN_STATE_KEY = 'artm_cs_login_state';

    function safeJson(response) {
        if (!response) {
            return [];
        }
        if (Array.isArray(response)) {
            return response;
        }
        if (response.items && Array.isArray(response.items)) {
            return response.items;
        }
        return [];
    }

    function detectPageType() {
        var body = document.body;
        if (!body) {
            return 'custom_url';
        }

        var classes = body.className || '';
        if (classes.indexOf('catalog-product-view') !== -1) {
            return 'product';
        }
        if (classes.indexOf('catalog-category-view') !== -1) {
            return 'category';
        }
        if (classes.indexOf('checkout-cart-index') !== -1) {
            return 'cart';
        }
        if (classes.indexOf('checkout-index-index') !== -1) {
            return 'checkout';
        }
        if (classes.indexOf('checkout-onepage-success') !== -1) {
            return 'success';
        }
        if (classes.indexOf('customer-account') !== -1) {
            return 'customer';
        }
        if (classes.indexOf('cms-') !== -1) {
            return 'cms';
        }

        return 'custom_url';
    }

    function getCustomerContext() {
        var customer = customerData.get('customer')();
        var loggedIn = !!(customer && customer.firstname);

        return {
            is_logged_in: loggedIn,
            customer_id: 0,
            customer_group_id: 0
        };
    }

    function getProductId() {
        var productInput = document.querySelector('input[name="product"]');
        if (!productInput) {
            return 0;
        }
        var val = parseInt(productInput.value, 10);
        return Number.isNaN(val) ? 0 : val;
    }

    function getCategoryId() {
        var node = document.querySelector('[data-category-id]');
        if (!node) {
            return 0;
        }
        var val = parseInt(node.getAttribute('data-category-id'), 10);
        return Number.isNaN(val) ? 0 : val;
    }

    function getOrCreateVisitorKey() {
        var existing = localStorage.getItem(VISITOR_KEY);
        if (existing) {
            return existing;
        }

        var key = 'guest_' + Date.now() + '_' + Math.floor(Math.random() * 1000000);
        localStorage.setItem(VISITOR_KEY, key);
        return key;
    }

    function incrementPageViews() {
        var current = parseInt(localStorage.getItem(PAGE_VIEWS_KEY) || '0', 10);
        if (Number.isNaN(current)) {
            current = 0;
        }
        current += 1;
        localStorage.setItem(PAGE_VIEWS_KEY, String(current));
        return current;
    }

    function postJson(url, payload) {
        return fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        }).then(function (res) {
            if (!res.ok) {
                return null;
            }
            return res.json().catch(function () {
                return null;
            });
        });
    }

    function createContainer() {
        var container = document.createElement('div');
        container.className = 'artm-cs-widget';
        return container;
    }

    function getMatchedLocation(survey) {
        if (!survey.locations || !survey.locations.length) {
            return null;
        }

        for (var i = 0; i < survey.locations.length; i++) {
            var location = survey.locations[i];
            var selector = location.css_selector || '';
            if (selector && document.querySelector(selector)) {
                return location;
            }
        }

        return survey.locations[0];
    }

    function getProgressPercent(index, total) {
        if (!total) {
            return 0;
        }
        return Math.round(((index + 1) / total) * 100);
    }

    function normalizeAnswers(answersMap) {
        var entries = Object.keys(answersMap).map(function (questionId) {
            return {
                question_id: parseInt(questionId, 10),
                value: answersMap[questionId]
            };
        });

        return entries
            .filter(function (item) {
                return !Number.isNaN(item.question_id);
            })
            .map(function (item) {
                var payload = {
                    question_id: item.question_id,
                    option_ids: [],
                    answer_text: ''
                };

                if (Array.isArray(item.value)) {
                    payload.option_ids = item.value.map(function (id) {
                        return parseInt(id, 10);
                    }).filter(function (id) {
                        return !Number.isNaN(id);
                    });
                } else if (typeof item.value === 'number') {
                    payload.option_ids = [item.value];
                } else if (typeof item.value === 'string') {
                    payload.answer_text = item.value;
                } else if (item.value && typeof item.value === 'object') {
                    if (item.value.option_ids) {
                        payload.option_ids = item.value.option_ids;
                    }
                    if (item.value.answer_text) {
                        payload.answer_text = item.value.answer_text;
                    }
                }

                return payload;
            });
    }

    function questionHasValue(question, value) {
        if (value === undefined || value === null) {
            return false;
        }

        if (question.type === 'checkbox') {
            return Array.isArray(value) && value.length > 0;
        }

        if (question.type === 'text' || question.type === 'textarea') {
            return String(value).trim() !== '';
        }

        return value !== '';
    }

    function validateCurrentQuestion(question, value) {
        if (!question.is_required) {
            return { valid: true, message: '' };
        }

        if (!questionHasValue(question, value)) {
            return { valid: false, message: 'This question is required.' };
        }

        if (question.type === 'checkbox' && Array.isArray(value)) {
            var minSel = question.min_selection || 0;
            var maxSel = question.max_selection || 0;
            if (minSel > 0 && value.length < minSel) {
                return { valid: false, message: 'Please select at least ' + minSel + ' option(s).' };
            }
            if (maxSel > 0 && value.length > maxSel) {
                return { valid: false, message: 'Please select at most ' + maxSel + ' option(s).' };
            }
        }

        return { valid: true, message: '' };
    }

    function createQuestionInput(question, answers, onChange) {
        var wrap = document.createElement('div');
        wrap.className = 'artm-cs-input-wrap';

        var qId = String(question.question_id);
        var current = answers[qId];

        if (question.type === 'text' || question.type === 'textarea') {
            var textInput = question.type === 'textarea'
                ? document.createElement('textarea')
                : document.createElement('input');
            if (question.type === 'text') {
                textInput.type = 'text';
            }
            textInput.className = 'artm-cs-field';
            textInput.value = typeof current === 'string' ? current : '';
            textInput.addEventListener('input', function () {
                onChange(textInput.value);
            });
            wrap.appendChild(textInput);
            return wrap;
        }

        if (question.type === 'dropdown') {
            var select = document.createElement('select');
            select.className = 'artm-cs-field';

            var placeholder = document.createElement('option');
            placeholder.value = '';
            placeholder.textContent = 'Select an option';
            select.appendChild(placeholder);

            (question.options || []).forEach(function (option) {
                var opt = document.createElement('option');
                opt.value = String(option.option_id);
                opt.textContent = option.title;
                if (String(current) === String(option.option_id)) {
                    opt.selected = true;
                }
                select.appendChild(opt);
            });

            select.addEventListener('change', function () {
                var val = parseInt(select.value, 10);
                onChange(Number.isNaN(val) ? '' : val);
            });
            wrap.appendChild(select);
            return wrap;
        }

        if (question.type === 'yes_no') {
            var yesNoOptions = [
                { option_id: 1, title: 'Yes' },
                { option_id: 2, title: 'No' }
            ];
            question.options = yesNoOptions;
            question.type = 'radio';
        }

        if (question.type === 'rating') {
            var ratingWrap = document.createElement('div');
            ratingWrap.className = 'artm-cs-rating';
            var currentRating = parseInt(current || 0, 10);

            for (var i = 1; i <= 5; i++) {
                (function (score) {
                    var btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'artm-cs-rating-star' + (score <= currentRating ? ' is-active' : '');
                    btn.textContent = '★';
                    btn.addEventListener('click', function () {
                        currentRating = score;
                        onChange(String(score));
                        Array.prototype.forEach.call(ratingWrap.children, function (child, idx) {
                            child.classList.toggle('is-active', idx < score);
                        });
                    });
                    ratingWrap.appendChild(btn);
                })(i);
            }

            wrap.appendChild(ratingWrap);
            return wrap;
        }

        var options = question.options || [];
        var isMulti = question.type === 'checkbox';
        var currentMulti = Array.isArray(current) ? current.map(String) : [];

        options.forEach(function (option) {
            var label = document.createElement('label');
            label.className = 'artm-cs-option';

            var input = document.createElement('input');
            input.type = isMulti ? 'checkbox' : 'radio';
            input.name = 'question_' + qId;
            input.value = String(option.option_id);
            if (isMulti) {
                input.checked = currentMulti.indexOf(String(option.option_id)) !== -1;
            } else {
                input.checked = String(current || '') === String(option.option_id);
            }

            input.addEventListener('change', function () {
                if (isMulti) {
                    var selected = Array.prototype.slice.call(
                        wrap.querySelectorAll('input[type="checkbox"]:checked')
                    ).map(function (el) {
                        return parseInt(el.value, 10);
                    });
                    onChange(selected);
                    return;
                }
                onChange(parseInt(input.value, 10));
            });

            var text = document.createElement('span');
            text.textContent = option.title;

            label.appendChild(input);
            label.appendChild(text);
            wrap.appendChild(label);
        });

        return wrap;
    }

    function renderSurveyCard(root, survey, state, handlers) {
        var questions = survey.questions || [];
        if (!questions.length) {
            root.innerHTML = '';
            return;
        }

        var index = state.currentIndex;
        var question = questions[index];

        var progress = getProgressPercent(index, questions.length);

        root.innerHTML = '';

        var card = document.createElement('div');
        card.className = 'artm-cs-card';

        var title = document.createElement('h3');
        title.className = 'artm-cs-title';
        title.textContent = survey.name || 'Quick Survey';

        var desc = document.createElement('p');
        desc.className = 'artm-cs-desc';
        desc.textContent = survey.description || '';

        var progressBar = document.createElement('div');
        progressBar.className = 'artm-cs-progress';
        progressBar.innerHTML = '<span style="width:' + progress + '%"></span>';

        var questionTitle = document.createElement('h4');
        questionTitle.className = 'artm-cs-q-title';
        questionTitle.textContent = question.title;

        var questionDesc = document.createElement('p');
        questionDesc.className = 'artm-cs-q-desc';
        questionDesc.textContent = question.description || '';

        var validation = document.createElement('p');
        validation.className = 'artm-cs-validation';

        var inputWrap = createQuestionInput(question, state.answers, function (value) {
            state.answers[String(question.question_id)] = value;
            validation.textContent = '';
        });

        var footer = document.createElement('div');
        footer.className = 'artm-cs-footer';

        var backBtn = document.createElement('button');
        backBtn.type = 'button';
        backBtn.className = 'artm-cs-btn artm-cs-btn-light';
        backBtn.textContent = 'Previous';
        backBtn.disabled = index === 0;
        backBtn.addEventListener('click', handlers.onPrev);

        var nextBtn = document.createElement('button');
        nextBtn.type = 'button';
        nextBtn.className = 'artm-cs-btn artm-cs-btn-primary';
        nextBtn.textContent = index === questions.length - 1 ? 'Submit' : 'Next';
        nextBtn.addEventListener('click', function () {
            var result = validateCurrentQuestion(question, state.answers[String(question.question_id)]);
            if (!result.valid) {
                validation.textContent = result.message;
                return;
            }
            handlers.onNext();
        });

        footer.appendChild(backBtn);
        footer.appendChild(nextBtn);

        card.appendChild(title);
        if (desc.textContent) {
            card.appendChild(desc);
        }
        card.appendChild(progressBar);
        card.appendChild(questionTitle);
        if (questionDesc.textContent) {
            card.appendChild(questionDesc);
        }
        card.appendChild(inputWrap);
        card.appendChild(validation);
        card.appendChild(footer);

        root.appendChild(card);
    }

    function renderThankYou(root) {
        root.innerHTML = '';

        var wrap = document.createElement('div');
        wrap.className = 'artm-cs-thankyou';
        wrap.innerHTML = '<h4>Thank you</h4><p>Your feedback has been recorded.</p>';
        root.appendChild(wrap);
    }

    function placeInline(container, survey) {
        var location = getMatchedLocation(survey);
        var selector = location && location.css_selector ? location.css_selector : (survey.display.inline_selector || '');
        if (!selector) {
            return false;
        }

        var target = document.querySelector(selector);
        if (!target) {
            return false;
        }

        var position = (location && location.position) || survey.display.inline_position || 'after';
        if (position === 'before') {
            target.parentNode.insertBefore(container, target);
        } else if (position === 'inside') {
            target.appendChild(container);
        } else if (position === 'replace') {
            target.parentNode.replaceChild(container, target);
        } else {
            target.parentNode.insertBefore(container, target.nextSibling);
        }

        return true;
    }

    function createPopupFrame() {
        var overlay = document.createElement('div');
        overlay.className = 'artm-cs-popup';
        overlay.innerHTML = '<div class="artm-cs-popup-backdrop"></div><div class="artm-cs-popup-panel"><button type="button" class="artm-cs-popup-close">x</button><div class="artm-cs-popup-content"></div></div>';
        document.body.appendChild(overlay);
        return overlay;
    }

    function addPopupTriggers(survey, context, openPopup) {
        var triggers = (survey.display.popup_triggers || []).slice();
        if (!triggers.length) {
            triggers = ['page_load'];
        }

        var opened = false;
        function openOnce() {
            if (opened) {
                return;
            }
            opened = true;
            openPopup();
        }

        triggers.forEach(function (trigger) {
            if (trigger === 'page_load') {
                setTimeout(openOnce, 0);
            }

            if (trigger === 'after_seconds') {
                var delay = (survey.display.popup_delay_seconds || 0) * 1000;
                setTimeout(openOnce, Math.max(delay, 0));
            }

            if (trigger === 'after_page_views') {
                var views = parseInt(localStorage.getItem(PAGE_VIEWS_KEY) || '0', 10);
                var minViews = parseInt(survey.display.popup_page_views || 0, 10);
                if (views >= minViews && minViews > 0) {
                    setTimeout(openOnce, 200);
                }
            }

            if (trigger === 'on_cart_page' && context.page_type === 'cart') {
                setTimeout(openOnce, 300);
            }

            if (trigger === 'on_checkout_page' && context.page_type === 'checkout') {
                setTimeout(openOnce, 300);
            }

            if (trigger === 'on_order_success' && context.page_type === 'success') {
                setTimeout(openOnce, 300);
            }

            if (trigger === 'exit_intent') {
                var handled = false;
                document.addEventListener('mouseout', function (event) {
                    if (handled) {
                        return;
                    }
                    if (event.clientY <= 0) {
                        handled = true;
                        openOnce();
                    }
                });
            }

            if (trigger === 'on_add_to_cart') {
                $(document).on('ajaxComplete.artmSurvey', function (event, xhr, settings) {
                    if (!settings || !settings.url) {
                        return;
                    }
                    if (String(settings.url).indexOf('checkout/cart/add') !== -1) {
                        openOnce();
                    }
                });
            }

            if (trigger === 'on_login' || trigger === 'on_logout') {
                var currentState = context.is_logged_in ? '1' : '0';
                var previousState = localStorage.getItem(LOGIN_STATE_KEY);
                localStorage.setItem(LOGIN_STATE_KEY, currentState);
                if (previousState === null) {
                    return;
                }
                if (trigger === 'on_login' && previousState === '0' && currentState === '1') {
                    openOnce();
                }
                if (trigger === 'on_logout' && previousState === '1' && currentState === '0') {
                    openOnce();
                }
            }
        });
    }

    function initSurveyWidget(config, survey, context) {
        var state = {
            currentIndex: 0,
            answers: {}
        };

        var endpoint = config.api;
        var container = createContainer();
        var isPopup = survey.display && survey.display.display_type === 'popup';

        function submitAnswers(onDone) {
            var payload = {
                survey_id: survey.survey_id,
                visitor_key: context.visitor_key,
                customer_id: context.customer_id,
                location_id: context.location_id || null,
                page_url: window.location.href,
                device: navigator.platform || '',
                browser: navigator.userAgent || '',
                answers: normalizeAnswers(state.answers)
            };

            postJson(endpoint.submit, payload).then(function () {
                renderThankYou(container);
                if (typeof onDone === 'function') {
                    onDone();
                }
            });
        }

        function renderStep() {
            renderSurveyCard(container, survey, state, {
                onPrev: function () {
                    state.currentIndex = Math.max(0, state.currentIndex - 1);
                    renderStep();
                },
                onNext: function () {
                    var total = (survey.questions || []).length;
                    if (state.currentIndex >= total - 1) {
                        submitAnswers();
                        return;
                    }
                    state.currentIndex += 1;
                    renderStep();
                }
            });
        }

        if (!isPopup) {
            if (!placeInline(container, survey)) {
                return;
            }

            renderStep();
            postJson(endpoint.impression, {
                survey_id: survey.survey_id,
                visitor_key: context.visitor_key,
                customer_id: context.customer_id
            });
            return;
        }

        var popup = createPopupFrame();
        var panel = popup.querySelector('.artm-cs-popup-content');
        var closeBtn = popup.querySelector('.artm-cs-popup-close');
        panel.appendChild(container);

        function openPopup() {
            popup.classList.add('is-open');
            renderStep();

            postJson(endpoint.popupOpen, {
                survey_id: survey.survey_id,
                visitor_key: context.visitor_key,
                customer_id: context.customer_id
            });
            postJson(endpoint.impression, {
                survey_id: survey.survey_id,
                visitor_key: context.visitor_key,
                customer_id: context.customer_id
            });
        }

        function closePopup() {
            popup.classList.remove('is-open');
            postJson(endpoint.closed, {
                survey_id: survey.survey_id,
                visitor_key: context.visitor_key,
                customer_id: context.customer_id
            });
        }

        closeBtn.addEventListener('click', closePopup);
        popup.querySelector('.artm-cs-popup-backdrop').addEventListener('click', closePopup);

        addPopupTriggers(survey, context, openPopup);
    }

    return function (config) {
        $(function () {
            incrementPageViews();

            var visitorKey = getOrCreateVisitorKey();
            var customerContext = getCustomerContext();

            var context = {
                page_type: detectPageType(),
                product_id: getProductId(),
                category_id: getCategoryId(),
                url: window.location.href,
                store_id: parseInt(config.storeId || 0, 10) || 0,
                visitor_key: visitorKey,
                customer_id: customerContext.customer_id,
                customer_group_id: customerContext.customer_group_id,
                is_logged_in: customerContext.is_logged_in
            };

            postJson(config.api.eligible, { context: context }).then(function (response) {
                var surveys = safeJson(response);
                if (!surveys.length) {
                    return;
                }

                initSurveyWidget(config, surveys[0], context);
            });
        });
    };
});
